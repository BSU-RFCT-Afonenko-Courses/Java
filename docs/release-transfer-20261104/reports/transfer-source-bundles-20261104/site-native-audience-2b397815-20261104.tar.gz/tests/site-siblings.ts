import { assert, assertEquals, assertRejects } from "./support.ts";
import { dirname, fromFileUrl, join } from "stdlib/path";
const repo = dirname(dirname(fromFileUrl(import.meta.url)));
const root = await Deno.makeTempDir({ prefix: "course-site-siblings-" });
try {
  await Deno.mkdir(join(root, "part"));
  await Deno.writeTextFile(
    join(root, "_quarto.yml"),
    "project:\n  type: website\n  output-dir: _site\nformat: html\nproject-download: {resources: {data: {path: assets}}}\nsubprojects: [part]\n",
  );
  await Deno.writeTextFile(join(root, "index.qmd"), "# Root\n");
  const add = await new Deno.Command(Deno.env.get("QUARTO") || "quarto", {
    args: ["add", repo, "--no-prompt"],
    cwd: root,
    stdout: "piped",
    stderr: "piped",
  }).output();
  assert(add.success);
  const { pre } = await import(
    `file://${root}/_extensions/course-site/application/compose.ts`
  );
  Deno.env.delete("QUARTO_PROJECT_RENDER_ALL");
  await assertRejects(() => pre(root), "SITE.SIBLING_MISSING", [
    "project-download",
    "public.ts",
    "module",
  ]);
  const source = join(
    root,
    "_extensions/project-download/public.ts",
  );
  await Deno.mkdir(dirname(source), { recursive: true });
  await Deno.writeTextFile(
    source,
    'export function resetDownloadRequests() { const error = new Error("CORE_SENTINEL", {cause: "original"}); error.name = "ExtensionDiagnostic"; Object.assign(error, {code: "CORE.SENTINEL"}); throw error; }\n',
  );
  try {
    await pre(root);
    throw new Error("expected foreign error");
  } catch (error) {
    assert(error instanceof Error);
    assertEquals((error as Error & { code: string }).code, "CORE.SENTINEL");
    assertEquals(error.cause, "original");
    assert(!error.message.includes("SITE.SIBLING_MISSING"));
    assert(error.stack?.includes("resetDownloadRequests"));
  }
  // Import-time failures of a present QRC module must also stay foreign.
  await Deno.writeTextFile(
    join(root, "_quarto.yml"),
    "project:\n  type: website\n  output-dir: _site\nformat: html\nreference-catalog: {namespace: root}\nsubprojects: [part]\n",
  );
  await Deno.mkdir(join(root, "_site"));
  await Deno.writeTextFile(join(root, "_site/index.html"), "current");
  Deno.env.set("QUARTO_PROJECT_OUTPUT_FILES", "_site/index.html");
  const qrc = join(
    root,
    "_extensions/reference-catalog/public.ts",
  );
  await Deno.mkdir(dirname(qrc), { recursive: true });
  await Deno.writeTextFile(
    qrc,
    'throw new Error("INITIALIZATION_SENTINEL", {cause: "module cause"});\n',
  );
  const { post } = await import(
    `file://${root}/_extensions/course-site/application/compose.ts`
  );
  try {
    await post(root);
    throw new Error("expected import error");
  } catch (error) {
    assert(error instanceof Error);
    assertEquals(error.message, "INITIALIZATION_SENTINEL");
    assertEquals(error.cause, "module cause");
    assert(error.stack?.includes("public.ts"));
  }
  console.log(
    "PASS missing sibling distinct from foreign call/import diagnostics and causes",
  );
} finally {
  await Deno.remove(root, { recursive: true });
}
