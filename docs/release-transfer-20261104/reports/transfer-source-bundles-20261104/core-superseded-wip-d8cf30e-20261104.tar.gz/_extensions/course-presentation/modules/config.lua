local __metrics=require("../observability/bridge").create_metrics("course-presentation",1)

-- Профили и course.view определяют публикуемое содержимое; этот модуль
-- задаёт способ его отображения после отбора.
local M = {}
local function message(detail, field)
  return 'PRESENTATION.CONFIG_INVALID: '..detail..'; источник='..quarto.doc.input_file..'; поле='..(field or 'course-presentation')
end
local vocabulary = require("./vocabulary")
local function allowed(values, value) for _, item in ipairs(values) do if item == value then return true end end; return false end
local function string(value) return value and pandoc.utils.stringify(value) or nil end
function M.read(meta)
  local input = meta["course-presentation"]
  if input == nil then input = {} end
  if type(input) ~= "table" or input.t == "MetaList" or input.t == "MetaInlines" then
      assert(false, message("course-presentation должен содержать YAML-словарь с параметром answers"))
  end
  for key, _ in pairs(input) do
    if key ~= "answers" then
      assert(false, message("Неизвестный параметр course-presentation: " .. tostring(key)))
    end
  end
  local reveal = quarto.doc.is_format("revealjs")
  local html = reveal or quarto.doc.is_format("html")
  local answers = string(input.answers) or "auto"
  if not allowed(vocabulary.presentationAnswers, answers) then
    assert(false, message("course-presentation.answers должен принимать значение auto или expanded", "course-presentation.answers"))
  end
  local lang = string(meta.lang) or "ru"
  local pedagogy = meta["course-pedagogy"] or {}
  if type(pedagogy) ~= "table" then assert(false, message("course-pedagogy должен содержать YAML-словарь параметров", "course-pedagogy")) end
  return {answers = answers, reveal = reveal, html = html,bank=meta["exercise-bank"]==true,
    assessmentTime = not (type(meta.course) == "table" and meta.course["assessment-time"] == false),
    ru = lang:match("^ru") ~= nil,
    defaults = pedagogy["document-defaults"] == true and {
      difficulty = string(meta.difficulty), time = string(meta.time),
      ["work-mode"] = string(meta["work-mode"])
    } or {}}
end
M.read=__metrics.wrap_sync({id="course-presentation.modules.config.read",kind='phase'},M.read)
return M
