import { join } from "stdlib/path";
import { inspectProject } from "../_extensions/course-site/infrastructure/config.ts";
import { commandProbe } from "./command-probe.ts";
import { assert, assertEquals } from "./support.ts";
const root = await Deno.makeTempDir({ prefix: "course-site-selection-" });
const previous = Deno.env.get("QUARTO");
try {
  const trace = join(root, "trace.jsonl");
  const probe = await commandProbe(root, previous || "quarto", trace);
  Deno.env.set("QUARTO", probe);
  await Deno.writeTextFile(
    join(root, "_quarto.yml"),
    "project:\n  type: website\n  output-dir: _site\n  render: [index.qmd, slides.qmd]\nformat: html\n",
  );
  await Deno.writeTextFile(join(root, "index.qmd"), "# Индекс\n");
  await Deno.writeTextFile(
    join(root, "slides.qmd"),
    "---\nformat: revealjs\n---\n# Слайды\n",
  );
  await Deno.writeTextFile(join(root, "unselected.qmd"), "# Вне selection\n");
  await Deno.writeTextFile(
    join(root, "_quarto-full.yml"),
    "project:\n  render: [slides.qmd]\nformat: revealjs\n",
  );
  const selected = await inspectProject(root, []);
  assertEquals(selected.selectedSources, ["index.qmd", "slides.qmd"]);
  assertEquals(selected.config.project.type, "website");
  const full = await inspectProject(root, ["full"]);
  assertEquals(full.selectedSources, ["slides.qmd"]);
  const commands = (await Deno.readTextFile(trace)).trim().split("\n").map(
    (line) => JSON.parse(line),
  );
  assertEquals(commands.length, 2);
  assert(
    commands.every((command) =>
      command.kind === "inspect" && command.args[1] === root
    ),
    "Publisher выполнил document inspect вместо project selection",
  );
  console.log(
    "PASS native selected sources/profiles без document format resolver",
  );
} finally {
  if (previous === undefined) Deno.env.delete("QUARTO");
  else Deno.env.set("QUARTO", previous);
  await Deno.remove(root, { recursive: true });
}
