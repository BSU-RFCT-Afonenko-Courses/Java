local __metrics=require("./observability/bridge").create_metrics("course-core",1)
local __perfWalk1=__metrics.wrap_walk({id="course-core.native-resources.walk.1",kind='ast_walk',scope="full-document"},function(node,filter)return node:walk(filter)end)
local diagnostics = require("./diagnostics")
local M={}
function M.uses(doc)
  local result,seen=pandoc.List(),{}
  local function add(node)
    local target=node.target or node.src
    if not target:match('^[%a][%w+.-]*:') and not target:match('^//') and target:sub(1,1)~='#' then
      target=target:gsub('[?#].*$','')
      if target~='' and not seen[target] then result:insert(target);seen[target]=true end
    end
  end
  local function raw(node)
    if node.format=='html' then
      for target in node.text:gmatch('[sS][rR][cC]%s*=%s*["\']([^"\']+)["\']') do add({target=target}) end
      for target in node.text:gmatch('[hH][rR][eE][fF]%s*=%s*["\']([^"\']+)["\']') do add({target=target}) end
    end
  end
  __perfWalk1(doc,{Image=add,Link=add,RawBlock=raw,RawInline=raw});return result
end
-- Служебный cache не является предметным ресурсом даже при прямой ссылке.
local function tool_cache(root,source)
  local name=pandoc.path.make_relative(source,root):gsub('\\','/')
  if name=='..' or name:match('^%.%./') or pandoc.path.is_absolute(name) then return false end
  if ('/'..name..'/'):find('/.cache/codex-tools/',1,true) then return true end
  local configured=os.getenv('XDG_CACHE_HOME')
  if not configured or not pandoc.path.is_absolute(configured) then return false end
  configured=pandoc.path.normalize(configured)
  local local_cache=pandoc.path.make_relative(configured,root)
  if local_cache=='.' or local_cache=='..' or local_cache:match('^%.%./') or pandoc.path.is_absolute(local_cache) then return false end
  return source==configured or source:sub(1,#configured+1)==configured..'/'
end
function M.facts(raw,public,canonical)
  local root=quarto.project.directory
  local rawProjectRoots,seenProjects=pandoc.List(),{}
  -- Reuse pre-projection validation facts; retain paths only, never private bodies.
  for _,fact in ipairs(canonical or {}) do
    if fact.project then
      if fact.project:sub(1,1)~='/' or fact.project:sub(1,2)=='//' then diagnostics.fail('RESOURCE.PROJECT_PATH_INVALID','Путь проекта должен начинаться с /: '..fact.project,{id=fact.id,field='project'}) end
      local path=pandoc.path.normalize(pandoc.path.join({root,fact.project:sub(2)}))
      if not seenProjects[path] then rawProjectRoots:insert(path);seenProjects[path]=true end
    end
  end
  local input=quarto.doc.input_file;if pandoc.path.is_relative(input) then input=pandoc.path.join({root,input}) end
  local outputRoot=quarto.project.output_directory or root;if pandoc.path.is_relative(outputRoot) then outputRoot=pandoc.path.join({root,outputRoot}) end
  local rawUses=M.uses(raw)
  local projectedUses=rawUses
  if not rawequal(raw,public) then projectedUses=M.uses(public) end
  local capturedFiles=pandoc.List()
  local publicUses={};for _,uri in ipairs(projectedUses) do publicUses[uri]=true end
  local view=raw.meta.course.view and pandoc.utils.stringify(raw.meta.course.view) or nil
  local generatedPrefix=input:gsub('%.[^./]+$','')..'_files/'
  -- Наблюдаем пути до переноса generated файлов native writer в outputRoot.
  for _,uri in ipairs(rawUses) do
    local decoded=uri:gsub('%%(%x%x)',function(h) return string.char(tonumber(h,16)) end)
    local source=decoded:sub(1,1)=='/' and pandoc.path.join({root,decoded:sub(2)}) or pandoc.path.join({pandoc.path.directory(input),decoded})
    source=pandoc.path.normalize(source)
    local file=not tool_cache(root,source) and io.open(source,'rb')
    if file then
      local observed={source=source,output=pandoc.path.join({outputRoot,pandoc.path.make_relative(source,root)})}
      -- PDF читает generated figures до native relocation.
      if FORMAT=='latex' and source:sub(1,#generatedPrefix)==generatedPrefix and (view=='full' or publicUses[uri]) then observed._bytes=file:read('*a') end
      file:close()
      capturedFiles:insert(observed)
    end
  end
  return {source=pandoc.path.make_relative(input,root),format=FORMAT,view=raw.meta.course.view and pandoc.utils.stringify(raw.meta.course.view) or nil,
    rawProjectRoots=rawProjectRoots,effectiveBase=pandoc.path.directory(input),outputDirectory=outputRoot,outputFile=quarto.doc.output_file,rawUses=rawUses,projectedUses=projectedUses,capturedFiles=capturedFiles}
end
M.uses=__metrics.wrap_sync({id="course-core.native-resources.uses",kind='phase'},M.uses)
M.facts=__metrics.wrap_sync({id="course-core.native-resources.facts",kind='phase'},M.facts)
return M
