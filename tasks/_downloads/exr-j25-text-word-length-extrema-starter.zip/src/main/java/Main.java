/** Поиск самых длинных и самых коротких слов. Условия и примеры приведены в README.md. */
public class Main {
    public static void main(String[] args) {
        // TODO: найдите и выведите все самые длинные и самые короткие слова.
    }
}
