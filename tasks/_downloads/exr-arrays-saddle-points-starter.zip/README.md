<a id="exr-arrays-saddle-points"></a>

<span class="theorem-title">**Упражнение 14.9 (Седловые точки матрицы)**</span>  

<div class="course-metadata">

<span class="course-meta course-meta-difficulty">Средний</span>

</div>

Подсчитайте и выведите число седловых точек квадратной матрицы `int[][]`. Позиция `(i, j)` является седловой точкой, если её значение минимально в строке `i` и максимально в столбце `j`. Оба условия нестрогие: равные значения также учитываются. При повторяющихся значениях подсчитывается каждая подходящая позиция.

Фиксированная исходная матрица имеет размер 3×3:

``` text
-3  0  3
 2 -1  0
 1  3 -2
```

Имя класса, методы, форму `main`, способ задания данных и оформление результата выберите самостоятельно. Алгоритм не предписан.

Покажите исходники и результат; объясните на позициях матрицы, почему должны одновременно выполняться оба условия и как учитываются равные значения.

Сдайте файл `Example.java` из `src/main/java` стартового проекта без объявления пакета.

<div class="project-download callout callout-style-simple callout-none no-icon">

<div class="callout-body d-flex">

<div class="callout-icon-container">

<i class='callout-icon no-icon'></i>

</div>

<div class="callout-body-container">

⤓ <a href="https://bsu-rfct-afonenko-courses.github.io/Java/tasks/_downloads/exr-arrays-saddle-points-starter.zip" class="project-download" download="">Скачать заготовку</a>

</div>

</div>

</div>

Для необязательной сборки нужен JDK 25 и Gradle 9.8. Откройте каталог с `settings.gradle` как Gradle-проект. `gradle classes` компилирует исходники; `gradle --console=plain -q run -PmainClass=ИмяКласса` запускает выбранный демонстрационный класс.

У задания полностью ручная оценка. Здесь нет оценочных автотестов и API-допуска. Успешная сборка не подтверждает решение; предъявите преподавателю исходники, результат и воспроизводимую команду по полному условию. JUnit и внешние зависимости не нужны. Не сдавайте `build`, `.gradle` и кеши IDE.

`Example` — необязательный компилируемый пример входа; вычислений в нём нет.

<div>

<a id="submission"></a>

## Сдача

</div>

Сдайте исходники способом, указанным преподавателем.
