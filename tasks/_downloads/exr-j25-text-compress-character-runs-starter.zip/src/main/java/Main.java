/** Сжатие серий одинаковых букв. Условия и примеры приведены в README.md. */
public class Main {
    public static void main(String[] args) {
        // TODO: сожмите серии одинаковых букв в строке из аргумента командной строки.
    }
}
