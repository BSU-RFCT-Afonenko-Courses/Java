import java.lang.AssertionError;
import java.lang.IllegalStateException;
import java.lang.Integer;
import java.lang.Object;
import java.lang.String;
import java.lang.System;
import java.lang.Throwable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.*;
public class PublicChecks {
 public record Observation(String actual,boolean passed){}
 private static final class CheckFailure extends AssertionError{CheckFailure(String s){super(s);}}
 public static void checkNormal(Observation o){if(!o.passed())throw new CheckFailure("Обычный открытый результат не соответствует условию");}
 public static void checkBoundary(Observation o){if(!o.passed())throw new CheckFailure("Граничный открытый результат не соответствует условию");}
 public static void main(String[]args){try{var n=observeNormal();System.out.println("PUBLIC normal | Создание без вызовов, apply для пустой строки/abc/abc; ожидается 0/3/3, condition=3, ветви=1/2, тот же аргумент | ФАКТИЧЕСКИ: "+n.actual());checkNormal(n);System.out.println("СТАТУС: открытый результат соответствует; исходник и объяснение проверяет преподаватель.");var b=observeBoundary();System.out.println("PUBLIC boundary | Принятый null даёт null; condition и true по одному вызову, false не вызывается | ФАКТИЧЕСКИ: "+b.actual());checkBoundary(b);System.out.println("СТАТУС: открытый результат соответствует; исходник и объяснение проверяет преподаватель.");}catch(CheckFailure e){System.err.println("СТАТУС: предметное несоответствие открытому ожиданию.");System.exit(1);}catch(Throwable e){System.err.println("СТАТУС: сбой выполнения; проверьте решение и привязку.");System.exit(2);}}

 public static Observation observeNormal(){int[]calls={0,0,0};boolean[]same={true};Object[]current={null};var trace=new ArrayList<String>();var f=TaskBinding.<String,Integer>run(s->{same[0]&=s==current[0];calls[0]++;trace.add("condition");return s.isEmpty();},s->{same[0]&=s==current[0];calls[1]++;trace.add("true");return 0;},s->{same[0]&=s==current[0];calls[2]++;trace.add("false");return s.length();});boolean creation=Arrays.equals(calls,new int[]{0,0,0});String empty="",value=new String("abc");current[0]=empty;Integer a=f.apply(empty);current[0]=value;Integer b=f.apply(value),c=f.apply(value);boolean ok=creation&&same[0]&&Objects.equals(a,0)&&Objects.equals(b,3)&&Objects.equals(c,3)&&Arrays.equals(calls,new int[]{3,1,2})&&trace.equals(List.of("condition","true","condition","false","condition","false"));return new Observation("при создании вызовов нет="+creation+"; результаты="+Arrays.asList(a,b,c)+"; вызовы="+Arrays.toString(calls)+"; порядок="+trace+"; тот же аргумент="+same[0],ok);}
 public static Observation observeBoundary(){int[]calls={0,0,0};boolean[]nulls={true};var rejected=new IllegalStateException("отказ невыбранной ветви");var f=TaskBinding.<Object,Object>run(x->{calls[0]++;nulls[0]&=x==null;return true;},x->{calls[1]++;nulls[0]&=x==null;return null;},x->{calls[2]++;throw rejected;});boolean creation=Arrays.equals(calls,new int[]{0,0,0});Object out;try{out=f.apply(null);}catch(IllegalStateException e){if(e!=rejected)throw e;return new Observation("невыбранная ветвь вызвана; вызовы="+Arrays.toString(calls),false);}return new Observation("при создании вызовов нет="+creation+"; результат="+out+"; вызовы="+Arrays.toString(calls)+"; передан null="+nulls[0],creation&&out==null&&nulls[0]&&Arrays.equals(calls,new int[]{1,1,0}));}

}
