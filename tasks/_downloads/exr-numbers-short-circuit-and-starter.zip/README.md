# Проверка положительного частного

Реализуйте программу в `src/main/java/Main.java`, сохранив точку входа
`Main.main(String[] args)`. Вспомогательные методы и классы разрешены.

Нужен JDK 25. Из каталога с этим README и папкой `src` скомпилируйте
все Java-исходники под `src/main/java`, включая вложенные пакеты.

В Linux, Bash:

```bash
find src/main/java -type f -name '*.java' -exec javac --release 25 -encoding UTF-8 -d out -sourcepath src/main/java {} +
```

В PowerShell 7:

```powershell
$sources = @(Get-ChildItem -LiteralPath 'src/main/java' -Recurse -File -Filter '*.java' |
    ForEach-Object { $_.FullName })
javac --release 25 -encoding UTF-8 -d out -sourcepath src/main/java $sources
```

Примеры запуска в Bash:

```bash
printf '7 2' | java -cp out Main
printf '7 0' | java -cp out Main
printf '1 2' | java -cp out Main
printf '' | java -cp out Main
```

Результаты — `true`, `false`, `false`, `false`. Пустой завершённый
поток включает демонстрацию пары `7 0`. Команда `printf` передаёт данные
через стандартный ввод и завершает поток; аргументы запуска для них
не используются.

После изменения исходников повторите компиляцию. `out` создаётся
при компиляции и в исходный комплект не включается.

После запуска решения выполните публичную самопроверку по инструкциям
в предоставленном [CHECKS.md](CHECKS.md).

Два открытых наблюдения помогают проверить результат. Обязательные
приёмы, исходник и объяснение оценивает преподаватель.

Покажите нулевой делитель и ненулевой делитель с частным, равным нулю.
Объясните по исходнику, какой операнд `&&` вычисляется первым и когда
деление не выполняется.

Предъявите исходники и демонстрацию. Объяснение проводится по коду
и результатам запуска; дополнительный письменный отчёт не требуется.

[condition/console-io.md](condition/console-io.md)
