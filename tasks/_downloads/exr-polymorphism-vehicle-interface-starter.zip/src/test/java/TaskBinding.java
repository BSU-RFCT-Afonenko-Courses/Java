import java.lang.Object;
class TaskBinding {
    static Object vehicle(int p, int f, int m) {
        return new Vehicle(p, f, m);
    }
    static int[] state(Object x) {
        IVehicle v = (IVehicle)x;
        return new int[]{v.getPassengers(), v.getFuelcap(), v.getMpg()};
    }
    static int range(Object x) {
        return ((IVehicle)x).range();
    }
    static double fuel(Object x, int miles) {
        return ((IVehicle)x).fuelNeeded(miles);
    }
    static void set(Object x, int field, int value) {
        IVehicle v = (IVehicle)x;
        switch (field) {case 0->v.setPassengers(value);case 1->v.setFuelcap(value);case 2->v.setMpg(value);}}}
