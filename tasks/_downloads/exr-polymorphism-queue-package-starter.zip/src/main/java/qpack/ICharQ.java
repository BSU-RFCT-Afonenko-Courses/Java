package qpack;
public interface ICharQ {void put(char c);char get();}
