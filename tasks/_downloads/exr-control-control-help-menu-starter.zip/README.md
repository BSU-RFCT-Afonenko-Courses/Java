<a id="exr-control-control-help-menu"></a>

<span class="theorem-title">**Упражнение 13.11 (Справочная система по управляющим операторам)**</span>  

<div class="course-metadata">

<span class="course-meta course-meta-difficulty">Средний</span>

</div>

Создайте простую справочную систему, отображающую синтаксис управляющих операторов Java. Первая версия выводит меню с операторами if и традиционным switch, ожидает выбора и отображает синтаксис выбранного оператора.

Затем расширьте программу: добавьте сведения о синтаксисе циклов for, while и do-while. Проверяйте выбор меню пользователем, организуя цикл до тех пор, пока не будет введён правильный вариант.

Текст меню, обозначения вариантов и оформление справки выберите самостоятельно. Покажите правильный выбор и повторный запрос после неправильного выбора. Объясните расширение начальной версии и условие завершения цикла проверки.

Сдайте файл `Main.java` из `src/main/java` стартового проекта без объявления пакета.

<div class="project-download callout callout-style-simple callout-none no-icon">

<div class="callout-body d-flex">

<div class="callout-icon-container">

<i class='callout-icon no-icon'></i>

</div>

<div class="callout-body-container">

⤓ <a href="https://bsu-rfct-afonenko-courses.github.io/Java/tasks/_downloads/exr-control-control-help-menu-starter.zip" class="project-download" download="">Скачать заготовку</a>

</div>

</div>

</div>

Для необязательной сборки в IDE нужны JDK 25 и установленный Gradle 9.8. Откройте извлечённый каталог с `settings.gradle` как Gradle-проект. Команда `gradle classes` компилирует исходники; `gradle -PmainClass=ИмяКласса run` запускает указанный класс и передаёт стандартный ввод.

Задание оценивается преподавателем полностью вручную. API-допуска и оценочных JUnit-тестов в этом проекте нет. Успех компиляции не подтверждает выполнение условия. Сдавайте свои исходники и команды запуска без `build`, `.gradle` и кешей IDE.

<div>

<a id="submission"></a>

## Сдача

</div>

Сдайте исходники способом, указанным преподавателем.
