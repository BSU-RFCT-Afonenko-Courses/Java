<a id="exr-control-inch-conversion-table"></a>

<span class="theorem-title">**Упражнение 13.6 (Таблица преобразования дюймов в метры)**</span>  

<div class="course-metadata">

<span class="course-meta course-meta-difficulty">Начальный</span>

</div>

Выведите таблицу перевода целого количества дюймов в метры для значений от 1 до 144 включительно — до 12 футов. Один фут содержит 12 дюймов, один метр — примерно 39,37 дюйма. Каждая строка содержит число дюймов и соответствующую длину в метрах; порядок строк — по возрастанию дюймов. После каждой группы из 12 строк выведите пустую строку. Точность отображения и выравнивание колонок выберите самостоятельно.

Покажите первую группу и конец таблицы. Объясните перевод единиц, выбранную точность отображения и условие вывода пустой строки.

Консольная программа выводит результат без приглашений к вводу. Числа разделяются пробельными символами; десятичный разделитель — точка.

Сдайте файл `Main.java` из `src/main/java` стартового проекта без объявления пакета.

<div class="project-download callout callout-style-simple callout-none no-icon">

<div class="callout-body d-flex">

<div class="callout-icon-container">

<i class='callout-icon no-icon'></i>

</div>

<div class="callout-body-container">

⤓ <a href="https://bsu-rfct-afonenko-courses.github.io/Java/tasks/_downloads/exr-control-inch-conversion-table-starter.zip" class="project-download" download="">Скачать заготовку</a>

</div>

</div>

</div>

Для необязательной сборки в IDE нужны JDK 25 и установленный Gradle 9.8. Откройте извлечённый каталог с `settings.gradle` как Gradle-проект. Команда `gradle classes` компилирует исходники; `gradle -PmainClass=ИмяКласса run` запускает указанный класс и передаёт стандартный ввод.

Задание оценивается преподавателем полностью вручную. API-допуска и оценочных JUnit-тестов в этом проекте нет. Успех компиляции не подтверждает выполнение условия. Сдавайте свои исходники и команды запуска без `build`, `.gradle` и кешей IDE.

<div>

<a id="submission"></a>

## Сдача

</div>

Сдайте исходники способом, указанным преподавателем.
